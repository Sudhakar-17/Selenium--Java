package extentReport;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport1 {

	WebDriver driver;
	ExtentReports extentReport;
	ExtentSparkReporter htmlReporter;
	ExtentTest testCase;


	@Test
	public void openGoogle() throws IOException {
		testCase = extentReport.createTest("Verify Google Title");
		testCase.log(Status.INFO, "Navigating to Google");
		driver.get("https://www.google.com/");
		String title = driver.getTitle();
		testCase.log(Status.INFO, "Actual title : "+title);
		testCase.log(Status.INFO, "Expected title : "+"Google");
		testCase.log(Status.INFO, "Verification of Actual and Expected");
		if (title.equals("Google")) {
			testCase.log(Status.PASS, "Actual and Expected Titles are same");
		} else {
			testCase.log(Status.FAIL, "Actual and Expected Titles are not same");
			TakesScreenshot screenshot = (TakesScreenshot) driver;
			File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);
			File destinationFile = new File("Google.png");
			FileHandler.copy(sourceFile, destinationFile);
			testCase.addScreenCaptureFromPath("Google.png");
		}
	}

	@Test
	public void openBing() throws IOException {
		testCase = extentReport.createTest("Verify Bing Title");
		testCase.log(Status.INFO, "Navigating to Bing");
		driver.get("https://www.bing.com/");
		String title = driver.getTitle();
		testCase.log(Status.INFO, "Actual title : "+title);
		testCase.log(Status.INFO, "Expected title : "+"bing");
		testCase.log(Status.INFO, "Verification of Actual and Expected");
		if (title.equals("bing")) {
			testCase.log(Status.PASS, "Actual and Expected Titles are same");
		} else {
			testCase.log(Status.FAIL, "Actual and Expected Titles are not same");
			TakesScreenshot screenshot = (TakesScreenshot) driver;
			File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);
			File destinationFile = new File("Bing.png");
			FileHandler.copy(sourceFile, destinationFile);
			testCase.addScreenCaptureFromPath("Bing.png");
		}
	}

	@Test
	public void openWikipedia() throws IOException {
		testCase = extentReport.createTest("Verify Wikipedia Title");
		testCase.log(Status.INFO, "Navigating to Wikipedia");
		driver.get("https://www.wikipedia.org/");
		String title = driver.getTitle();
		testCase.log(Status.INFO, "Actual title : "+title);
		testCase.log(Status.INFO, "Expected title : "+"Wikipedia");
		testCase.log(Status.INFO, "Verification of Actual and Expected");
		if (title.equals("wikipedia")) {
			testCase.log(Status.PASS, "Actual and Expected Titles are same");
		} else {
			testCase.log(Status.FAIL, "Actual and Expected Titles are not same");
			TakesScreenshot screenshot = (TakesScreenshot) driver;
			File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);
			File destinationFile = new File("Wikipedia.png");
			FileHandler.copy(sourceFile, destinationFile);
			testCase.addScreenCaptureFromPath("Wikipedia.png");
		}
	}

	@BeforeSuite
	public void launchBrowser() {
		extentReport = new ExtentReports();
		htmlReporter = new ExtentSparkReporter("ExtentReport.html");
		extentReport.attachReporter(htmlReporter);
		System.setProperty("webdriver.chrome.driver", "E:\\Software\\Drivers\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@AfterSuite
	public void CloseBrowser() {
		driver.quit();
		extentReport.flush();
	}
}
